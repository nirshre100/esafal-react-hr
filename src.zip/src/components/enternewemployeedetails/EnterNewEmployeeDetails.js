import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';


class EnterNewEmployeeDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            startDate: undefined
        }
    }


    setStartDate(date) {
        this.setState({
            startDate: date
        });
    }

    render() {

        return (
            <div className="container" >
                <div className="well">
                    <fieldset>
                        <div className="form-search form-group">
                            <div className="col-md-12">
                                <div id="legend">
                                    <legend>Enter New Employee Details</legend>
                                </div>
                                <div className="row">
                                    <div className="col-md-4">
                                        <div className="input-group svX1">
                                            <label className="input-group-addon imagetype-width" id="firstName-addon">Employee ID No.</label>
                                            <input className="form-control" type="text" id="firstName" name="firstName" />
                                        </div>
                                    </div>
                                    <div className="col-md-5">
                                        <div className="input-group svX2">
                                            <label className="input-group-addon imagetype-width" id="lastName-addon">Employee Name</label>
                                            <input className="form-control" type="text" id="lastName" name="lastName" />
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Gender</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">FEMALE</option>
                                                <option value="hello">MALE</option>
                                                <option value="hello">OTHER</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Marital Status</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">MARRIED</option>
                                                <option value="hello">SINGLE</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="col-md-5">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Personal Contact No.</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon"> Residence No.</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>




                                    <div className="col-md-12">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Current Address</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-12">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Permanent Address</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>



                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Date of Birth AD</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>
                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Date of Birth BS</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Office email</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Personal email</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Employee Qualification</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Citizenship No.</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Father's Name</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Spouce Name</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Relation</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>




                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Citizenship District</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">ACHHAM</option>
                                                <option value="hello">ARGHAKHANCHI</option>
                                                <option value="hello">BAITADI</option>
                                                <option value="hello">BAJHANG</option>
                                                <option value="hello">BAJURA</option>
                                                <option value="hello">BANKE</option>
                                                <option value="hello">BARA</option>
                                                <option value="hello">BARDIA</option>
                                                <option value="hello">BHAKTAPUR</option>
                                                <option value="hello">BHOJPUR</option>
                                                <option value="hello">BHOJPUR</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Grand Father Name</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>



                                    <img src="..." className="rounded float-left" alt="..."></img>



                                </div>
                                <div className="row"></div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="col-md-12"><button id="submit" className="btn btn-primary">Save</button>
                                <button id="cancel" className="btn btn-primary">Close</button>

                            </div>
                        </div>
                    </fieldset>

                </div></div>)

    }
}

export default EnterNewEmployeeDetails;
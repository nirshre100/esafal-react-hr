import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';


class CreateDesignation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            startDate: undefined
        }
    }


    setStartDate(date) {
        this.setState({
            startDate: date
        });
    }

    render() {

        return (
            <div className="container" >
                <div className="well">
                    <fieldset>
                        <div className="form-search form-group">
                            <div className="col-md-12">
                                <div id="legend">
                                    <legend>Create New Designation</legend>
                                </div>
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="input-group svX1">
                                            <label className="input-group-addon imagetype-width" id="firstName-addon">Designation</label>
                                            <input className="form-control" type="text" id="firstName" name="firstName" />
                                        </div>
                                    </div>
                                </div>
                                <div className="row"></div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="col-md-12"><button id="submit" className="btn btn-primary">Save</button>
                                <button id="cancel" className="btn btn-primary">Close</button>
                            </div>
                        </div>
                    </fieldset>

                </div></div>)

    }
}

export default CreateDesignation;
import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';


class NewEmployeeRegistration extends Component {
    constructor(props) {
        super(props);
        this.state = {
            startDate: undefined
        }
    }


    setStartDate(date) {
        this.setState({
            startDate: date
        });
    }

    render() {

        return (
            <div className="container" >
                <div className="well">
                    <fieldset>
                        <div className="form-search form-group">
                            <div className="col-md-12">
                                <div id="legend">
                                    <legend>New Employee Registration</legend>
                                </div>
                                <div className="row">
                                    <div className="col-md-4">
                                        <div className="input-group svX1">
                                            <label className="input-group-addon imagetype-width" id="firstName-addon">ID</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">100001</option>
                                                <option value="hello">100002</option>
                                                <option value="hello">100003</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div className="col-md-8">
                                        <div className="input-group svX2">
                                            <label className="input-group-addon imagetype-width" id="lastName-addon">Name</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">LAXMI</option>
                                                <option value="hello">NIRAJ</option>
                                                <option value="hello">SAMIR</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Branch</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">KATHMANDU</option>
                                                <option value="hello">JHAPA</option>
                                                <option value="hello">JANAKPUR</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Post</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">ACCOUNTANT</option>
                                                <option value="hello">CEO</option>
                                                <option value="hello">DRIVER</option>
                                            </select> </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Level</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">LEVEL-1</option>
                                                <option value="hello">LEVEL-2</option>
                                                <option value="hello">LEVEL-3</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div className="panel panel-default" />

                                    <div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Join Date AD</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Join Date BS</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Expire Date AD</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>


                                    <div className="col-md-3">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Expire Date BS</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-6">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Department</label>
                                            <input className="form-control" type="drop-down" id="email" name="email" />
                                        </div>
                                    </div>



                                    <div className="col-md-6">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Shift</label>
                                            <select className="form-control" name="status" id="status" >
                                                <option value="ALL">MORNING</option>
                                                <option value="hello">NIGHT</option>
                                                <option value="hello">NORMAL</option>
                                            </select>
                                        </div>
                                    </div>

                                    <h4>.</h4>
                                    <div className="panel panel-default" />

                                    <h4>CONTRACT TYPE OPTION</h4>
                                    <div className="panel panel-default" />



                                    <div className="col-md-10">
                                        <div className="input-group svX3">
                                            <label className="radio-inline" id="lastName-addon">REGULAR</label>
                                            <input className="radio-inline" type="radio" id="lastName" name="lastName" />
                                            <label className="radio-inline" id="lastName-addon">PARTTIME</label>
                                            <input className="radio-inline" type="radio" id="lastName" name="lastName" />
                                            <label className="radio-inline" id="lastName-addon">DAILY WAGES TAXABLE</label>
                                            <input className="radio-inline" type="radio" id="lastName" name="lastName" />
                                            <label className="radio-inline" id="lastName-addon">DAILY WAGES NON-TAXABLE</label>
                                            <input className="radio-inline" type="radio" id="lastName" name="lastName" />

                                        </div>
                                    </div>

                                    <h4>.</h4>
                                    <div className="panel panel-default" />

                                    <h4>REGULAR STAFF FACILITIES OPTION</h4>
                                    <div className="panel panel-default" />

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Basic Salary</label>
                                            <input className="form-control" type="text" id="email" name="email" />
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">
                                            <label className="input-group-addon imagetype-width" id="email-addon">Provident Fund</label>
                                            <input className="form-control" type="text" id="email" name="email" />
                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">% of Basic Salary</label>

                                        </div>

                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">RF/Gratuty Fund</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Communication</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Fuel/Month</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Lunch/Month</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Convence/Month</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Rent/Month</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Medical/Month</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Bonus Per Year</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Year</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Festival Allowance</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon"></label>Rs. Per Day
                                        </div>
                                    </div>


                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Daily Allowance</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Day</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Daily Allowance(I)</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Daily Allowance(II)</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX3">

                                            <label className="input-group-addon imagetype-width" id="email-addon">Daily Allowance(III)</label>
                                            <input className="form-control" type="text" id="email" name="email" />

                                            <input className="" type="checkbox" id="email" name="email" />
                                            <label className="" id="email-addon">Rs. Per Month</label>
                                        </div>
                                    </div>

                                    <input className="" type="checkbox" id="email" name="email" />
                                    <label className="" id="email-addon">Over Time Facility</label>
                                    <input className="" type="checkbox" id="email" name="email" />
                                    <label className="" id="email-addon">Leave Facility</label>
                                </div>

                                <h4><div className="panel panel-default" /></h4>
                                <h4>PARTTIME FACILITIES OPTION</h4>
                                <label className="input-group-addon imagetype-width" id="email-addon">Salary Amount</label>
                                <input className="form-control" type="text" id="email" name="email" />
                                <h4>.</h4>
                                <h4><div className="panel panel-default" /></h4>


                                <h4>DAILY WAGES FACILITIES OPTION</h4>
                                <div className="col-md-5">
                                    <div className="input-group svX3">
                                        <label className="input-group-addon imagetype-width" id="email-addon">Remuneration</label>
                                        <input className="form-control" type="drop-down" id="email" name="email" />

                                    </div>
                                </div>

                                <label>Per Day</label>

                                <div className="col-md-5">
                                    <div className="input-group svX1">
                                        <label className="input-group-addon imagetype-width" id="firstName-addon">Working Hour</label>
                                        <input className="form-control" type="text" id="firstName" name="firstName" />
                                    </div>
                                </div>

                                <h4>.</h4>
                                <h4><div className="panel panel-default" /></h4>


                                <h4>RETIREMENT FUND CONTRIBUTION OPTION</h4>
                                <div className="panel panel-default" />

                                <div className="col-md-4">
                                    <div className="input-group svX3">
                                        <label className="input-group-addon imagetype-width" id="email-addon">Provident Fund</label>
                                        <input className="form-control" type="text" id="email" name="email" />
                                        <input className="" type="checkbox" id="email" name="email" />
                                        <label className="" id="email-addon">Amt. Per Month</label>

                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="input-group svX3">

                                        <label className="input-group-addon imagetype-width" id="email-addon">RF/Gratury Fund</label>
                                        <input className="form-control" type="text" id="email" name="email" />

                                        <input className="" type="checkbox" id="email" name="email" />
                                        <label className="" id="email-addon">Rs. Per Month</label>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="input-group svX3">

                                        <label className="input-group-addon imagetype-width" id="email-addon">CIT</label>
                                        <input className="form-control" type="text" id="email" name="email" />

                                        <input className="" type="checkbox" id="email" name="email" />
                                        <label className="" id="email-addon">Amt. Per Month</label>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="input-group svX3">

                                        <label className="input-group-addon imagetype-width" id="email-addon">Insurance Premium</label>
                                        <input className="form-control" type="text" id="email" name="email" />

                                        <input className="" type="checkbox" id="email" name="email" />
                                        <label className="" id="email-addon">Amt. Per Year</label>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="input-group svX3">

                                        <label className="input-group-addon imagetype-width" id="email-addon">Medical Insurance</label>
                                        <input className="form-control" type="text" id="email" name="email" />

                                        <input className="" type="checkbox" id="email" name="email" />
                                        <label className="" id="email-addon">Amt. Per Year</label>
                                    </div>
                                </div>
                                <div className="col-md-8">
                                </div>
                            </div>

                            <h4>.</h4>
                            <div className="panel panel-default" />
                            <h4>OVER TIME OPTION</h4>
                            <div className="col-md-5">
                                <div className="input-group svX3">
                                    <label className="input-group-addon imagetype-width" id="email-addon">Remuneration</label>
                                    <input className="form-control" type="drop-down" id="email" name="email" />

                                </div>
                            </div>

                            <label>Per Day</label>
                            <div className="col-md-5">
                                <div className="input-group svX1">
                                    <label className="input-group-addon imagetype-width" id="firstName-addon">Maximum Hour</label>
                                    <input className="form-control" type="text" id="firstName" name="firstName" />
                                </div>
                            </div>

                            <h4>.</h4>
                            <div className="panel panel-default" />

                            <div className="col-md-4">
                                <div className="input-group svX1">
                                    <label className="input-group-addon imagetype-width" id="firstName-addon">Total Income Per Month</label>
                                    <input className="form-control" type="text" id="firstName" name="firstName" />
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="input-group svX2">
                                    <label className="input-group-addon imagetype-width" id="lastName-addon">Total RF Contribution Per Month</label>
                                    <input className="form-control" type="text" id="lastName" name="lastName" />
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="input-group svX2">
                                    <label className="input-group-addon imagetype-width" id="lastName-addon">Net Salary Per Month</label>
                                    <input className="form-control" type="text" id="lastName" name="lastName" />
                                </div>
                            </div>




                            <div className="row"></div>
                        </div>

                        <div className="form-group">
                            <div className="col-md-12">
                                <button id="save" className="btn btn-primary">SAVE</button>
                                <button id="close" className="btn btn-primary">CLOSE</button>

                            </div>
                        </div>


                    </fieldset>

                </div></div >)

    }
}

export default NewEmployeeRegistration;
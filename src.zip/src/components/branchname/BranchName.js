import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';


class BranchName extends Component {
    constructor(props) {
        super(props);
        this.state = {
            startDate: undefined
        }
    }


    setStartDate(date) {
        this.setState({
            startDate: date
        });
    }

    render() {

        return (
            <div className="container" >
                <div className="well">
                    <fieldset>
                        <div className="form-search form-group">
                            <div className="col-md-12">
                                <div id="legend">
                                    <legend>Create New Branch</legend>
                                </div>
                                <div className="row">
                                    <div className="col-md-4">
                                        <div className="input-group svX1">
                                            <label className="input-group-addon imagetype-width" id="firstName-addon">Branch Name</label>
                                            <input className="form-control" type="text" id="firstName" name="firstName" />
                                        </div>
                                    </div>

                                    <div className="col-md-6">
                                        <div className="col-md-8">
                                            <div className="input-group svX3">
                                                <label className="input-group-addon imagetype-width" id="status-addon">Location</label>
                                                <select className="form-control" name="status" id="status" >
                                                    <option value="ALL">BHAKTAPUR</option>
                                                    <option value="hello">BIRTAMOD</option>
                                                    <option value="hello">DANG</option>
                                                    <option value="hello">DILLIBAZAR</option>
                                                    <option value="hello">HEAD OFFICE</option>
                                                    <option value="hello">INDRACHOWK</option>
                                                    <option value="hello">ITAHARI</option>

                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div className="row"></div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="col-md-12"><button id="submit" className="btn btn-primary">Save</button>
                                <button id="cancel" className="btn btn-primary">Close</button>

                            </div>
                        </div>
                    </fieldset>

                </div></div>)

    }
}

export default BranchName;
import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';


class CreateNewLeavetyp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            startDate: undefined
        }
    }


    setStartDate(date) {
        this.setState({
            startDate: date
        });
    }

    render() {

        return (
            <div className="container" >
                <div className="well">
                    <fieldset>
                        <div className="form-search form-group">
                            <div className="col-md-12">
                                <div id="legend">
                                    <legend>Create New Leave Type</legend>
                                </div>
                                <div className="row">
                                    <div className="col-md-4">
                                        <div className="input-group svX1">
                                            <label className="input-group-addon imagetype-width" id="firstName-addon">Leave Type</label>
                                            <input className="form-control" type="text" id="firstName" name="firstName" />
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="input-group svX2">
                                            <label className="input-group-addon imagetype-width" id="lastName-addon">Leave Day</label>
                                            <input className="form-control" type="text" id="lastName" name="lastName" />
                                        </div>
                                    </div>

                                    <div className="col-md-4">
                                        <div className="input-group svX2">
                                            <label className="" id="lastName-addon">Accumulated Option</label>
                                            <label className="radio-inline" id="lastName-addon">Yes</label>
                                            <input className="radio-inline" type="radio" id="lastName" name="lastName" />
                                            <label className="radio-inline" id="lastName-addon">No</label>
                                            <input className="radio-inline" type="radio" id="lastName" name="lastName" />
                                        </div>
                                    </div>
                                    <div>
                                    </div>
                                </div>
                                <div className="row"></div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="col-md-12"><button id="submit" className="btn btn-primary">Save</button>
                                <button id="cancel" className="btn btn-primary">Close</button>

                            </div>
                        </div>
                    </fieldset>

                </div></div>)



    }
}

export default CreateNewLeavetyp;
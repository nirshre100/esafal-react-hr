import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Select from 'react-select'
import NewAreaChild from './NewAreaChild';

class NewArea extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cancellationPolicies: [],
            startDate: undefined,
            page: 1,
            pageNum: 0,
            area: '',
        }
    }


    setStartDate(date) {
        this.setState({
            startDate: date
        });
    }

    getPolicyJson() {
        return {
            defaultDescription: 'test',//this.state.defaultDescription,
            id: '22' //this.state.id
        }
    }

    validateAddNewPolicy() {
        window.scrollTo(0, 0);
        if (this.state.id === '' || this.state.defaultDescription === '') {
            this.setState({ type: true, msg: ['Please input all field'] });
            return false;
        }
        return true;
    }

    addNewPolicy(e) {
        e.preventDefault();
        this.setState({ type: false, msg: [] });
        if (!this.validateAddNewPolicy()) return
        const url = window.baseApiUrl + '/cancellation';
        const self = this;
        var ajaxCall = window.ajaxCall;
        var data = this.getPolicyJson();
        const arr = this.state.cancellationPolicies;

        arr.push(data)

        self.setState({ cancellationPolicies: arr });

        const onSuccessMethod = data => {
            // 	window.scrollTo(0, 0);
            // 	//self.props.getAllCancellationPolicies();
            // 	self.setState({ showAddNew: false });
            // 	self.setState({ msg: [data.defaultDescription + ' new policy added successfully '] });
            // 	self.setState({ type: false });
        }

        let onFailMethod = (err) => {
            window.scrollTo(0, 0);
            var errArr = [];
            if (err.responseJSON && err.responseJSON.details) {
                err.responseJSON.details.forEach(function (item) {
                    errArr.push(item.message);
                });
            } else if (err.responseJSON) {
                errArr.push(err.responseJSON.message);
            } else {
                errArr.push(err.responseText);
            }

            self.setState({ type: true });
            self.setState({ msg: errArr });
            // self.setState({msg:error.response.data});
        }

        //ajaxCall(url, 'POST', data, onSuccessMethod, onFailMethod)
    }

    switchArea(newValue) {
        this.setState({
            area: newValue
        })
    }

    render() {
        const area = [
            { value: 'Acham', label: 'Acham' },
            { value: 'ARGHAKHANCHI', label: 'ARGHAKHANCHI' },
            { value: 'ARGHAKHANCHI', label: 'ARGHAKHANCHI' }

        ]
        var newData = this.state.cancellationPolicies || [];
        var baseAppUrl = window.baseAppUrl;

        let per_page = 15; //window.per_page;
        const pages = newData && Math.ceil(this.state.cancellationPolicies.length / per_page);
        const current_page = this.state.page;
        const start_offset = (current_page - 1) * per_page;
        let start_count = 0;

        return (
            <div className="container" >
                <div className="well">
                    <fieldset>
                        <div className="form-search form-group">
                            <div className="col-md-12">
                                <div id="legend">
                                    <legend>Create New Area</legend>
                                </div>
                                <div className="row">
                                    <div className="col-md-3">
                                        <div className="input-group svX1">
                                            <label className="input-group-addon imagetype-width" id="firstName-addon">Area No.</label>
                                            <input className="form-control" type="number" id="firstName" name="firstName" />
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="input-group svX2">
                                            <label className="input-group-addon imagetype-width" id="lastName-addon">Area Name</label>
                                            <input className="form-control" type="text" id="lastName" name="lastName" />
                                        </div>
                                    </div>


                                    <div className="col-md-6">

                                        <div className="col-md-8">
                                            <div className="input-group svX3">
                                                <label className="input-group-addon imagetype-width" id="status-addon">District</label>
                                                <Select
                                                    ref="areaSelect"
                                                    placeholder='area'
                                                    options={area}
                                                    simpleValue
                                                    clearable={false}
                                                    name="selected-arrea"
                                                    value={this.state.area}
                                                    onChange={this.switchArea.bind(this)}
                                                    searchable={this.state.searchable}
                                                    required="required"
                                                />

                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div className="row"></div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="col-md-12"><button id="submit" className="btn btn-primary" onClick={this.addNewPolicy.bind(this)}>Save</button>
                                <button id="cancel" className="btn btn-primary">Close</button>

                            </div>
                        </div>
                    </fieldset>

                    <div className="well" >

                        <table id="userTable" className="table table-bordered table-stripped results">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Status</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {newData && newData.length > 0 ? newData.map((item, idx) => {
                                    if (idx >= start_offset && start_count < per_page) {
                                        start_count++;
                                        return (
                                            <NewAreaChild
                                                key={idx}
                                                index={idx}
                                                id={item.id}
                                                defaultDescription={item.defaultDescription}
                                            />
                                        )
                                    }
                                }) : null}

                            </tbody>
                        </table>

                    </div>

                </div></div>)

    }
}

export default NewArea;
import React from 'react';
import { Switch, Route } from 'react-router-dom';
import User from '../components/user/User';
import NewMemberEntry from '../components/newmember/NewMemberEntry';
import MemberEditfrom from '../components/memberEdit/MemberEditfrom';
import BranchName from '../components/branchname/BranchName';
import NewArea from '../components/newarea/NewArea';
import NewDepartment from '../components/department/NewDepartment';
import CreateDesignation from '../components/designation/CreateDesignation';
import CreateNewLevel from '../components/createlevel/CreateNewLevel';
import CreateNewLeavetyp from '../components/createleavetyp/CreateNewLeavetyp';
import EnterNewEmployeeDetails from '../components/enternewemployeedetails/EnterNewEmployeeDetails';
import RemunerationTaxParameter from '../components/remunerationtaxparameter/RemunerationTaxParameter';
import NewEmployeeRegistration from '../components/newemployeeregistration/NewEmployeeRegistration';









import Logout from './Logout';

const Main = () => (
	<main>
		<Switch>
			<Route path='/admin/app/pages/logout' component={Logout} />
			<Route path='/admin/app/pages/user' component={User} />
			<Route path='/admin/app/pages/popularCity' component={User} />
			<Route path='/admin/app/pages/niraj' component={NewMemberEntry} />
			<Route path='/admin/app/pages/ram' component={MemberEditfrom} />

			<Route path='/admin/app/pages/area' component={NewArea} />
			<Route path='/admin/app/pages/branchname' component={BranchName} />
			<Route path='/admin/app/pages/department' component={NewDepartment} />
			<Route path='/admin/app/pages/designation' component={CreateDesignation} />
			<Route path='/admin/app/pages/createlevel' component={CreateNewLevel} />
			<Route path='/admin/app/pages/createleavetyp' component={CreateNewLeavetyp} />
			<Route path='/admin/app/pages/enternewemployeedetails' component={EnterNewEmployeeDetails} />
			<Route path='/admin/app/pages/remunerationtaxparameter' component={RemunerationTaxParameter} />
			<Route path='/admin/app/pages/newemployeeregistration' component={NewEmployeeRegistration} />





		</Switch>
	</main>
)

export default Main;

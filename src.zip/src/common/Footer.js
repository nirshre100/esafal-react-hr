import React from 'react';

const Footer = () => (
	<div>
		
	</div>
)

export default Footer;